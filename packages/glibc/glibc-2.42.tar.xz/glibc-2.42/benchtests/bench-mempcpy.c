/* Measure mempcpy functions.
   Copyright (C) 2013-2025 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <https://www.gnu.org/licenses/>.  */

#define MEMCPY_RESULT(dst, len) (dst) + (len)
#define TEST_MAIN
#define TEST_NAME "mempcpy"
#include "bench-string.h"

char *
generic_mempcpy (char *dst, const char *src, size_t n)
{
  return memcpy (dst, src, n) + n;
}

IMPL (mempcpy, 1)
IMPL (generic_mempcpy, 0)

#include "bench-memcpy.c"
